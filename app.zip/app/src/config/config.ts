export default{
    "mongodb" : {
        "connectionUrl":
      "mongodb://curio:curio1234!!!@13.234.165.138:27017/plej?authSource=admin"
    },
    "authentication" : {
      "secretKey" : 'BiAppCompany_Ashwath_Nagar_2016', // Secret Key for Authentication
      "saltRounds" : 10 // Salt rounds for hashing. Caution: This may affect Performance
    },
    "redis" : {
      
    }
}