//Import various datasources here and initialize it
import {MongooseUtil} from '../utils';

let mongoose = new MongooseUtil();
